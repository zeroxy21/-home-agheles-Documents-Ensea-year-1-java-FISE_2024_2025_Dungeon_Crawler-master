import java.awt.*;

public interface Displayable {
    public void draw (Graphics g);
}
